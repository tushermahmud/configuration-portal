export class SearchData {
    keyWord: string;
}
